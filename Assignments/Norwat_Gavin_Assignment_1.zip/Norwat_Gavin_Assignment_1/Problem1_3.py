#Gavin Norwat
#700746314
#Assignment 1 / problem 1.3
#Description: Display a pattern

#Using the print function to display a pattern
print("FFFFFFF   U     U   NN     NN")
print("FF        U     U   NNN    NN")
print("FFFFFFF   U     U   NN N   NN")
print("FF         U   U    NN  N  NN")
print("FF          UUU     NN    NNN")

