#Gavin Norwat
#700746314
#Assignment 1 / problem 1.1
#description: Display the messages provided

#using the print function display the first message
print("Welcome to Python")

#Using the print function display the second message
print("Weclome to Computer Science")

#Using the print function display the third message
print("Programming is fun")
