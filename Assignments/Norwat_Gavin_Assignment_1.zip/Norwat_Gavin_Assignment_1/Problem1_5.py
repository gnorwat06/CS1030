#Gavin Norwat
#700746314
#Assignment 1 / problem 1.5
#Description: Compute expressions

#use the print function to compute the given equation

print((9.5 * 4.5 - 2.5 * 3) / (45.5 - 3.5))
