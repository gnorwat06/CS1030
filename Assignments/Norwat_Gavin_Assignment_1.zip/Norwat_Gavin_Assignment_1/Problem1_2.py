#Gavin Norwat
#700746314
#Assignment 1 / problem 1.2
#Description: Display the same message 5 times

#using the print function display the provided message 5 times
print("Welcome to Python")
print("Welcome to Python")
print("Welcome to Python")
print("Welcome to Python")
print("Welcome to Python")
