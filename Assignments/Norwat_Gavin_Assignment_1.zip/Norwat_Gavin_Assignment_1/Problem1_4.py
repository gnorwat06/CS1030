#Gavin Norwat
#700746314
#Assignment 1 / problem 1.4
#Description: Print a table

#use the print function to display a table
print("a      a^2    a^3")
print("1      1      1")
print("2      4      8")
print("3      9      27")
print("4      16     64")

