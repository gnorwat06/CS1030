#Gavin Norwat
#700746314
#Assignment 2 / Problem 2.1
#Description: converting a celsius degreee to fahrenheit

#Step 1: Prompt the user to input a celsius degree
celsius = float(input("Enter a degree in Celsius: "))

#Step 2: convert the user value to Fahrenheit
fahrenheit = (9 / 5) * celsius + 32

#step 3: Display the results
print(celsius,"Celsius is",fahrenheit,"fahrenheit")
