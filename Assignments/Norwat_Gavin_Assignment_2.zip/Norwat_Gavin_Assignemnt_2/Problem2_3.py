#Gavin Norwat
#700746314
#Assignemtn 2 / problem 2.3
#Description: convert feet into meters

#Step 1: Obtain a value for feet
feet = float(input("Enter a value for feet: "))

#Step 2: Convert feet to meters
meters = feet * .305

#step 3: Display results
print(feet,"feet is",meters,"meters")
