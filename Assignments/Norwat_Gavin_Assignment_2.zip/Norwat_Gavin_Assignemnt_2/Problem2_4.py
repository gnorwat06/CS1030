#Gavin Norwat
#700746314
#Assignemtn 2 / problem 2.4
#Description: convert pounds into kilograms

#Step 1: Obtain a value for pounds
pounds = float(input("Enter a number in pounds: "))

#Step 2: convert pounds to kilograms
kilograms = pounds * .454

#Step 3: Display results
print(pounds,"pounds is",kilograms,"kilograms")
